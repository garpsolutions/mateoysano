<?php
    $conexion = new mysqli("localhost","root","","mateo") or die("No logro conectar a la base de datos");
?>
